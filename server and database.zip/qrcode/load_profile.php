<?php
$servername = "localhost";
$username = "root";
$dbname = "qrcode";
$password = "";



try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
//program tampil data barang
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $username1 = $_GET['username'];
    $msql = "select * from users where username= '$username1'";
    $stmt = $conn->prepare($msql);
    $stmt->execute();
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($data);
} else if ($_SERVER['REQUEST_METHOD'] === 'POST') {


    // SAAT USERNAME TIDAK ADA DI DATABASE, MAKA AKAN DITAMBAHKAN




    // $scheck_username = "select * from users where username = '" . $_POST['username'] . "'";
    // $stmt = $conn->prepare($scheck_username);
    // $stmt->execute();
    // $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    // if (count($data) > 0) {
    //     echo json_encode(['error' => 'Username sudah ada']);
    // } else {
    //     $msql = "insert into users (username, password, nama, email, no_hp, alamat, gambar) values ('" . $_POST['username'] . "','" . $_POST['password'] . "','" . $_POST['nama'] . "','" . $_POST['email'] . "','" . $_POST['no_hp'] . "','" . $_POST['alamat'] . "','" . $_POST['gambar'] . "')";
    //     $stmt = $conn->prepare($msql);
    //     $stmt->execute();
    //     $data = ['username' => $_POST['username'], 'password' => $_POST['password'], 'nama' => $_POST['nama'], 'email' => $_POST['email'], 'no_hp' => $_POST['no_hp'], 'alamat' => $_POST['alamat'], 'gambar' => $_POST['gambar']];
    //     echo json_encode($data);
    // }



    class emp
    {
    }


    $username = $_POST['username'];
    $image = $_POST['image'];
    $about = $_POST['about'];

    $nama_file = $username . ".png";

    $path = "profile_image/" . $nama_file;

    // sesuiakan ip address laptop/pc atau URL server
    $actualpath = "http://192.168.11.19/android/upload_image/$path";

    if ($about == "") {

        $msql = "insert into users (username) values (?)";
        $stat = $conn->prepare($msql);
        $res = $stat->execute([$username]);
    } else {
        $msql = "update users set image = '$nama_file', about = '$about' where username = '$username'";
        $stat = $conn->prepare($msql);
        $res = $stat->execute();

        if ($res) {
            file_put_contents($path, base64_decode($image));

            $response = new emp();
            $response->success = 1;
            $response->message = "Gambar disimpan";
            die(json_encode($response));
        } else {
            $response = new emp();
            $response->success = 0;
            $response->message = "Upload gambar gagal";
            die(json_encode($response));
        }
    }
}
