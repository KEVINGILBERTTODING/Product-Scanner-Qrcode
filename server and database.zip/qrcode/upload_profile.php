<?php
include_once('connection2.php');

class emp
{
}

$image = $_POST['gambar'];
$username = $_POST['username'];
$about = $_POST['about'];

$nama_file = $username . ".png";

$path = "profile_image/" . $nama_file;

// sesuiakan ip address laptop/pc atau URL server
$actualpath = "http://192.168.11.19/android/profile_image/$path";

$query = mysqli_query($conn, "INSERT INTO users (username, gambar) VALUES ('$username', '$nama_file')");

if ($query) {
	file_put_contents($path, base64_decode($image));

	$response = new emp();
	$response->success = 1;
	$response->message = "Nota sudah disimpan";
	die(json_encode($response));
} else {
	$response = new emp();
	$response->success = 0;
	$response->message = "Upload nota gagal";
	die(json_encode($response));
}
mysqli_close($con);
